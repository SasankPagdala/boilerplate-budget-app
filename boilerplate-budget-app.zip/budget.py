class Category:
  #PART 1
  def __init__(mine, category_name):
    mine.category_name = category_name
    mine.total = 0.0
    mine.ledger = []

  #Printing first line must be 30 characters in length
  def __repr__(mine):
    f = f"{mine.category_name:*^30}\n"
    temp = 0
    #Formating in lines through right alligning 
    for item in mine.ledger:
      f += f'{item["description"]}{item["amount"]:>{30-len(item["description"])}}\n'
      temp += item["amount"]

    f += f"Total: 123"
    return f
      
    
  #Defining and calling Methods    
  def deposit(mine, amount, description):
    mine.total += amount
    mine.ledger.append({"amount": amount, 
                       "description": description})
  
  def withdraw(mine, amount, *args):
    can_Withdraw = mine.check_funds(amount)

    #Formating description 
    description = args[0] if args else ""

    #Formating withdraw amount
    if can_Withdraw:  
      mine.total -= amount
      mine.ledger.append({"amount": -amount, 
                         "description": description})
    return can_Withdraw
    
  def get_balance(mine):
    return mine.total

  def transfer(mine, amount, instance):
    can_Transfer = mine.check_funds(amount)

    #Formating Transfer amount
    if can_Transfer:
      mine.withdraw(amount, f"Transfer to {instance.category_name}")
      instance.deposit(amount, f"Transfer from {mine.category_name}")
      
    return can_Transfer

  def check_funds(mine, amount):
    if amount > mine.total:
      return False
    return True



#Testing instances from category class
food = Category('Food')
entertainment = Category('Entertainment')
food.deposit(100, "something")
food.transfer(25.5, entertainment)
# food.withdraw(20, "beans")
# print(food.ledger)  
# print(food)
# print(entertainment.ledger)
# print(food.get_balance())
# print(entertainment.get_balance())




#PART 2
def create_spend_chart(categories):
  f = "Percentage spent by category \n"

  abs_total = 0
  cats = {}
  #nested loop
  for cat in categories:
  #total number of each withdrawal 
    cat_total = 0
    for item in cat.ledger:
      item_amount = item["amount"]
      if item_amount < 0:
        abs_total += item_amount
        cat_total += item_amount

    cats[cat.category_name] = abs(cat_total)

    
  abs_total = abs(abs_total)

  #Percentage of category values
  for key, val in cats.items():
    percentage = (val / abs_total) * 100
    cats[key] = percentage

  print(cats)
  
  for x in range(100, -1, -10):
    #Formatting the range of numbers from 0-100
    f +=  f"{str(x)+'|':>4}"
    for val in cats.values():
      if val >= x:
        f += " o"
    f += "\n"

  #Dash length line value
  cat_Length = len(cats.values())
  f += f"    {(cat_Length*3+1) * '-'}\n" 

  index = 0
  while True:
    try:
      temp_str = ""
      for key in cats.keys():
        temp_str += key[index]
      index += 1
      f += f"     {temp_str}\n"
    except:
      break 
    
  print(f)
           
create_spend_chart([food, entertainment])